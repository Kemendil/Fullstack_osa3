const mongoose = require('mongoose')

const url = 'mongodb://puhelinluettelo_sovellus:<salasana>@ds161653.mlab.com:61653/puhelinluettelo_tietokanta'

mongoose.connect(url)

const henkiloSkeema = new mongoose.Schema({
    nimi: String,
    numero: String,
    vastaaHakusanaa: Boolean
})

const Henkilo = mongoose.model('Henkilo', henkiloSkeema)

module.exports = Henkilo