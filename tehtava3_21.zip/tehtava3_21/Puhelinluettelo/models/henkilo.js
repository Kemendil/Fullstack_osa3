const mongoose = require('mongoose')

if ( process.env.NODE_ENV !== 'production' ) {
    require('dotenv').config()
}

const url = process.env.MONGODB_URI

mongoose.connect(url)

const henkiloSkeema = new mongoose.Schema({
    nimi: String,
    numero: String,
    vastaaHakusanaa: Boolean
})

const Henkilo = mongoose.model('Henkilo', henkiloSkeema)

module.exports = Henkilo