import React from 'react'
import Henkilokaavake from './components/Henkilokaavake'
import Rajaus from './components/Rajaus'
import Numerot from './components/Numerot'
import henkilopalvelu from './services/henkilot'
import Ilmoitusviesti from './components/Ilmoitusviesti'

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      henkilot: [],
      uusiNimi: '',
      uusiNumero: '',
      hakusana: '',
      naytaKaikki: true,
      viesti: null
    }

    setInterval(() => {
      this.rajaaHakua()}, 500)

  }

  componentDidMount() {
    henkilopalvelu
      .lataaKaikki()
      .then(vastaus => {
        this.setState( {henkilot: vastaus.data})
      })
  }

  lisaaHenkilo = (event) => {
    event.preventDefault()
    const nimilista = this.state.henkilot.map((henkilonNimi) => (henkilonNimi.nimi));
    if (!nimilista.includes(this.state.uusiNimi)) {
      const henkiloOlio = {
        nimi: this.state.uusiNimi,
        numero: this.state.uusiNumero,
        vastaaHakusanaa: true
      }
        
      henkilopalvelu
        .luo(henkiloOlio)
        .then(vastaus => {
          henkilopalvelu
            .lataaKaikki()
            .then(vastaus => {
              this.setState( {
                henkilot: vastaus.data,
                viesti: this.state.uusiNimi + ' lisättiin puhelinluetteloon',
                uusiNimi: '',
                uusiNumero: ''
              })
              this.ilmoitusviestinPoistaja()
            })
        })  
    } else {
      if (window.confirm(this.state.uusiNimi + ' on jo luettelossa, korvataanko vanha numero uudella?')) {
        const loydettavaHenkilo = this.state.henkilot.find(h => h.nimi === this.state.uusiNimi)  
        const muutettuHenkilo = {...loydettavaHenkilo, numero: this.state.uusiNumero }

        henkilopalvelu
          .korvaa(muutettuHenkilo)
          .then(vastaus => {
            henkilopalvelu
              .lataaKaikki()
              .then(vastaus => {
                this.setState( {
                  henkilot: vastaus.data,
                  viesti: 'Henkilön ' + this.state.uusiNimi + ' puhelinnumeroksi vaihdettiin ' + this.state.uusiNumero,
                  uusiNimi: '',
                  uusiNumero: ''
                })
                this.ilmoitusviestinPoistaja()
              })           
          })
          .catch(error => {
            alert(this.state.uusiNimi + ' on valitettavasti jo poistettu palvelimelta')              
            this.setState( {
              uusiNimi: '',
              uusiNumero: ''  
            })
          })
      }
    }    
  }

  uudenHenkilonKasittelija = (event) => {
    this.setState({ uusiNimi: event.target.value })
  }

  uudenNumeronKasittelija = (event) => {
    this.setState({ uusiNumero: event.target.value })
  }

  rajaaHakua = (event) => {
    if (this.state.hakusana.length === 0) {
      this.setState({ naytaKaikki: true})
    } else {
      this.setState({ naytaKaikki: false})      
      const henkilotKopio = [...this.state.henkilot]
      for (let i = 0; i < henkilotKopio.length; i++) {
        const henkilonNimiPienella = henkilotKopio[i].nimi.toLowerCase()
        const hakusanaPienella = this.state.hakusana.toLowerCase()
        if (!henkilonNimiPienella.includes(hakusanaPienella)) {
          henkilotKopio[i].vastaaHakusanaa = false
        } else if (henkilonNimiPienella.includes(hakusanaPienella)) {
          henkilotKopio[i].vastaaHakusanaa = true
        }
      }
      this.setState({ henkilot: henkilotKopio})
    }
  }

  ilmoitusviestinPoistaja = () => {
    setTimeout(() => {
      this.setState({ viesti: null})}, 5000)
  }


  hakusananKasittelija = (event) => {
    this.setState({ hakusana: event.target.value})
  }

  poistaja = (henkilo) => {
    if (window.confirm('Poistetaanko ' + henkilo.nimi + '?')) {
      henkilopalvelu
        .poista(henkilo)
        .then(vastaus => {
          henkilopalvelu
            .lataaKaikki()
            .then(vastaus => {
              this.setState( {
                henkilot: vastaus.data,
                viesti: henkilo.nimi + ' poistettiin puhelinluettelosta'
              })
              this.ilmoitusviestinPoistaja()
          })  
      })       
    }
  } 

  render() {
    const naytettavat =
      this.state.naytaKaikki ?
        this.state.henkilot :
        this.state.henkilot.filter(henkilo => henkilo.vastaaHakusanaa === true)
            
    return (
      <div>
        <h2>Puhelinluettelo</h2>
        <Ilmoitusviesti viesti={this.state.viesti} />
        <Rajaus 
          rajaaHakua={this.rajaaHakua}
          hakusana={this.state.hakusana}
          hakusananKasittelija={this.hakusananKasittelija}
          poistaRajaus={this.poistaRajaus}            
          />
        <Henkilokaavake 
          lisaaHenkilo={this.lisaaHenkilo}
          uusiNimi={this.state.uusiNimi}
          uusiNumero={this.state.uusiNumero}
          uudenHenkilonKasittelija={this.uudenHenkilonKasittelija}
          uudenNumeronKasittelija={this.uudenNumeronKasittelija}
          />
        <Numerot 
          naytettavat={naytettavat}
          poistaja={this.poistaja}
          />
      </div>
    )
  }
}
  
  export default App