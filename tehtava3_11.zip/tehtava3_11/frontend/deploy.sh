#!/bin/sh
npm run build
rm -rf ../../Osa3_tehtavat/Puhelinluettelo/build
cp -r build ../../Osa3_tehtavat/Puhelinluettelo/