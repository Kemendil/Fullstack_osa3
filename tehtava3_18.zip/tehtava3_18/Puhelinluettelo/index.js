const express = require('express')
const app = express()
const bodyParser = require('body-parser')
const morgan = require('morgan')
const cors = require('cors')
const Henkilo = require('./models/henkilo')

app.use(bodyParser.json())
app.use(cors())
app.use(express.static('build'))

morgan.token('data', function(req, res) { return JSON.stringify(req.body)})

app.use(morgan(':method :url :data :status :res[content-length] - :response-time ms'))

let henkilot = [
        {
            "nimi": "Arto Hellas",
            "numero": "040-123456",
            "id": 1,
            "vastaaHakusanaa": true
        },
        {
            "nimi": "Martti Tienari",
            "numero": "040-543345",
            "vastaaHakusanaa": true,
            "id": 2
        },
        {
            "nimi": "Arto Järvinen",
            "numero": "040-123456",
            "vastaaHakusanaa": true,
            "id": 3
        },
        {
            "nimi": "Lea Kutvonen",
            "numero": "040-123456",
            "vastaaHakusanaa": true,
            "id": 4
        }
]    

const henkilonMuokkaaja = (henkilo) => {
    return {
        nimi: henkilo.nimi,
        numero: henkilo.numero,
        vastaaHakusanaa: henkilo.vastaaHakusanaa,
        id: henkilo._id
    }
}   

app.get('/api/henkilot', (pyynto, vastaus) => {
    Henkilo
        .find({})
        .then(henkilos => {
            vastaus.json(henkilos.map(henkilonMuokkaaja))
        })    
})

app.get('/api/henkilot/:id', (pyynto, vastaus) => {
    Henkilo
        .findById(pyynto.params.id)
        .then(henkilo => {
            if (henkilo) {
                vastaus.json(henkilonMuokkaaja(henkilo))
            } else {
                vastaus.status(404).end()
            }
        })
        .catch(error => {
            vastaus.status(400).send({ error: 'vääränmuotoinen id'})
        })
})

app.get('/info', (pyynto, vastaus) => {
    const aikaleima = new Date
    Henkilo
        .find({})
        .count({})
        .then(numero => {
            vastaus.send('<p>' + 'puhelinluettelossa ' + numero + ' henkilön tiedot' + '</p>' + '<p>' + aikaleima + '</p>').end()
        })
})

app.delete('/api/henkilot/:id', (pyynto, vastaus) => {
    Henkilo
        .findByIdAndDelete(pyynto.params.id)
        .then(result => {
            vastaus.status(204).end()  
            })
        .catch(error => {
            vastaus.status(400).send({ error: 'vääränmuotoinen id'})
        })      
})

const idNumeroGeneraattori = () => {
    let randomNumero = Math.random() * (henkilot.length * 80)
    let randomInt = Math.round(randomNumero)
    
    return randomInt
}

app.post('/api/henkilot', (pyynto, vastaus) => {
    const body = pyynto.body

    const henkilo = new Henkilo({
        nimi: body.nimi,
        numero: body.numero,
        vastaaHakusanaa: true
    })

    henkilo
        .save()
        .then(tallennettuHenkilo => {
            vastaus.json(henkilonMuokkaaja(tallennettuHenkilo))
        })
})

app.put('/api/henkilot/:id', (pyynto, vastaus) => {
    Henkilo
        .findByIdAndUpdate(pyynto.params.id, pyynto.body)
        .then(paivitettyHenkilo => {
            vastaus.json(henkilonMuokkaaja(paivitettyHenkilo))
            })
        .catch(error => {
            console.log(error)
            vastaus.status(400).send({ error: 'väärinmuotoiltu id'})
        })
})

const PORT = process.env.PORT || 3001
app.listen(PORT, () => {
    console.log('Palvelin toimii portissa', PORT)
})
  