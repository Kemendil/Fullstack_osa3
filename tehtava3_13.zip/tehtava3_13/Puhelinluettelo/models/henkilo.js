const mongoose = require('mongoose')

const url = 'mongodb://puhelinluettelo_sovellus:<salasana>@ds161653.mlab.com:61653/puhelinluettelo_tietokanta'

mongoose.connect(url)

const Henkilo = mongoose.model('Henkilo', {
    nimi: String,
    numero: String,
    vastaaHakusanaa: Boolean
})

module.exports = Henkilo