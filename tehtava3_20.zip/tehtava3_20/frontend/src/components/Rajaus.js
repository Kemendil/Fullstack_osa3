import React from 'react'

const Rajaus = (props) => {
  return (
    <div>
      <form>
        <div>
          rajaa näytettäviä<input
          value={props.hakusana}
          onChange={props.hakusananKasittelija}
          />
        </div>
      </form>
    </div>
  )  
}

 export default Rajaus