import React from 'react'

const Ilmoitusviesti = ({ viesti }) => {
    if (viesti === null) {
        return null
    }
    return (
        <div className="ilmoitus">
            {viesti}
        </div>
    )
}
 
export default Ilmoitusviesti