const express = require('express')
const app = express()
const bodyParser = require('body-parser')

app.use(bodyParser.json())

let henkilot = [
        {
            "nimi": "Arto Hellas",
            "numero": "040-123456",
            "id": 1,
            "vastaaHakusanaa": true
        },
        {
            "nimi": "Martti Tienari",
            "numero": "040-543345",
            "vastaaHakusanaa": true,
            "id": 2
        },
        {
            "nimi": "Arto Järvinen",
            "numero": "040-123456",
            "vastaaHakusanaa": true,
            "id": 3
        },
        {
            "nimi": "Lea Kutvonen",
            "numero": "040-123456",
            "vastaaHakusanaa": true,
            "id": 4
        }
    ]
    
app.get('/api/henkilot', (pyynto, vastaus) => {
    vastaus.json(henkilot)
})

app.get('/api/henkilot/:id', (pyynto, vastaus) => {
    const id = Number(pyynto.params.id)
    const henkilo = henkilot.find(henkilo => henkilo.id === id)
    
    if ( henkilo ) {
        vastaus.json(henkilo)
    } else {
        vastaus.status(404).end()
    }
})

app.get('/info', (pyynto, vastaus) => {
    let henkiloitaLuettelossa = henkilot.length
    let teksti = 'puhelinluettelossa ' + henkiloitaLuettelossa + ' henkilön tiedot'
    const aikaleima = new Date
    vastaus.send('<p>' + teksti + '</p>' + '<p>' + aikaleima + '</p>')
})

app.delete('/api/henkilot/:id', (pyynto, vastaus) => {
    const id = Number(pyynto.params.id)
    henkilot = henkilot.filter(henkilo => henkilo.id !== id)
    vastaus.status(204).end()    
})

const idNumeroGeneraattori = () => {
    let randomNumero = Math.random() * (henkilot.length * 80)
    let randomInt = Math.round(randomNumero)
    
    return randomInt
}

app.post('/api/henkilot', (pyynto, vastaus) => {
    const body = pyynto.body
    const nimetListalla = henkilot.map(h => h.nimi)

    if (body.nimi === undefined) {
        return vastaus.status(400).json({ virhe: 'Henkilön nimi puuttuu.'})    
    } else if (body.numero === undefined) {
        return vastaus.status(400).json({ virhe: 'Henkilön puhelinnumero puuttuu.'})    
    } else if (nimetListalla.includes(body.nimi)) {
        return vastaus.status(400).json({ virhe: 'Henkilö löytyy jo luettelosta. Sama nimi voi olla vain kerran luettelossa.'})    
    }

    const henkilo = {
        nimi: body.nimi,
        numero: body.numero,
        vastaaHakusanaa: true,
        id: idNumeroGeneraattori()
    }

    henkilot = henkilot.concat(henkilo)

    vastaus.json(henkilo)
})

const PORT = 3001
app.listen(PORT, () => {
    console.log('Palvelin toimii portissa', PORT)
})
  