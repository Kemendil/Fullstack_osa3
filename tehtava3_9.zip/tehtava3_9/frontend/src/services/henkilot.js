import axios from 'axios'
const baseUrl = 'http://localhost:3001/api/henkilot'

const lataaKaikki = () => {
    return axios.get(baseUrl)
}

const luo = (uusiOlio) => {
    return axios.post(baseUrl, uusiOlio)
}

const poista = (poistettavaHenkilo) => {
    const poistettavanUrl = baseUrl + '/' + poistettavaHenkilo.id
    return axios.delete(poistettavanUrl)
}

const korvaa =(paivitettyHenkilo) => {
    const korvattavanUrl = baseUrl + '/' + paivitettyHenkilo.id 
    return axios.put(korvattavanUrl, paivitettyHenkilo)
}

export default { lataaKaikki, luo, poista, korvaa }