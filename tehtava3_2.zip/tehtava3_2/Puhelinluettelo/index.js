const express = require('express')
const app = express()

let henkilot = [
        {
            "nimi": "Arto Hellas",
            "numero": "040-123456",
            "id": 1,
            "vastaaHakusanaa": true
        },
        {
            "nimi": "Martti Tienari",
            "numero": "040-543345",
            "vastaaHakusanaa": true,
            "id": 2
        },
        {
            "nimi": "Arto Järvinen",
            "numero": "040-123456",
            "vastaaHakusanaa": true,
            "id": 3
        },
        {
            "nimi": "Lea Kutvonen",
            "numero": "040-123456",
            "vastaaHakusanaa": true,
            "id": 4
        }
    ]
    
app.get('/api/henkilot', (pyynto, vastaus) => {
    vastaus.json(henkilot)
})

app.get('/info', (pyynto, vastaus) => {
    let henkiloitaLuettelossa = henkilot.length
    let teksti = 'puhelinluettelossa ' + henkiloitaLuettelossa + ' henkilön tiedot'
    const aikaleima = new Date
    vastaus.send('<p>' + teksti + '</p>' + '<p>' + aikaleima + '</p>')
})

const PORT = 3001
app.listen(PORT, () => {
    console.log('Palvelin toimii portissa', PORT)
})
  