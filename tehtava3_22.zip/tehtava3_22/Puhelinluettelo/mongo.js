const mongoose = require('mongoose')

const url = 'mongodb://puhelinluettelo_sovellus:<salasana>@ds161653.mlab.com:61653/puhelinluettelo_tietokanta'

mongoose.connect(url)

const Henkilo = mongoose.model('Henkilo', {
    nimi: String,
    numero: String,
    vastaaHakusanaa: Boolean
})

const henkilo = new Henkilo({
    nimi: process.argv[2],
    numero: process.argv[3],
    vastaaHakusanaa: true
})

if (process.argv.length > 2) {
    henkilo
        .save()
        .then(vastaus => {
            console.log('lisätään henkilö',henkilo.nimi,'numero',henkilo.numero,'luetteloon')
            mongoose.connection.close()
        })
}

if (process.argv.length === 2) {
    console.log('puhelinluettelo:')
    Henkilo
        .find()
        .then(vastaus => {
            vastaus.forEach(h => console.log(h.nimi,h.numero))
            mongoose.connection.close()
        })
}
