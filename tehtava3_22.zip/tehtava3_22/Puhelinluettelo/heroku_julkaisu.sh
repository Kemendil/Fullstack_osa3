#!/bin/sh
git add -A
git commit -m "Initiate app."
git push heroku master